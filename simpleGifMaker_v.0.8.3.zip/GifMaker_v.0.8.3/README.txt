I'm currently learning web programming so this gif-making 
project is a client-server programming exercise for me.
It is make with HTML, CSS, PHP, JavaScript, Ajax and XAMPP server.

This project uses the imagick library of PHP.
The first goal is to create a minimally animated GIF with 
image movement, brightness and transparency changes.

The HTML page handles the operation of PHP and displays the 
result of running the PHP code. (E.g. animated GIF.)

This part of the project is made under the 
GNU General Public License v3.0.

Further information: András Kosik ak@egyez.com
