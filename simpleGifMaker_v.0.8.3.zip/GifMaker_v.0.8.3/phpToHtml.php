<?php 
function getPhpImg($pictureBe){
    echo(base64_encode($pictureBe));
   // echo(base64_decode($pictureBe)); 
    }
 function getPhpGif($pictureBe){
  // // echo (base64_encode($pictureBe)); 
 /////////////////////////////////// echo strlen($pictureBe);
 //// echo (base64_encode($pictureBe->getImagesBlob()));
 //Header("Content-Type: image/gif");
 //fpassthru($pictureBe); 

 
 }   
    
 ?>